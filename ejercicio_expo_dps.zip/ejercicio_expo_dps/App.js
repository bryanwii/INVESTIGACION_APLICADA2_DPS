import React, { useState, useEffect } from 'react';
import { StyleSheet, View, Text, TouchableOpacity, ActivityIndicator } from 'react-native';

// API simulada
const mockApi = {
  fetchSensorData: async (sensorId) => {
    await new Promise(resolve => setTimeout(resolve, 500));
    return {
      sensorId,
      temperature: (Math.random() * 30 + 10).toFixed(1),
      humidity: (Math.random() * 50 + 30).toFixed(1),
      location: `Zona ${Math.floor(Math.random() * 5) + 1}`,
      lastUpdated: new Date().toISOString()
    };
  }
};

export default function App() {
  const [sensorData, setSensorData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const sensorId = "EnvTrack-001";

  const fetchData = async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await mockApi.fetchSensorData(sensorId);
      setSensorData(data);
    } catch (err) {
      setError("Error al cargar datos del sensor");
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
    const interval = setInterval(fetchData, 5000);
    return () => clearInterval(interval);
  }, []);

  if (loading && !sensorData) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" />
        <Text>Cargando datos del sensor...</Text>
      </View>
    );
  }

  if (error) {
    return (
      <View style={styles.errorContainer}>
        <Text style={styles.errorText}>{error}</Text>
        <TouchableOpacity style={styles.retryButton} onPress={fetchData}>
          <Text style={styles.retryButtonText}>Reintentar</Text>
        </TouchableOpacity>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <View style={styles.arPanel}>
        <Text style={styles.titleText}>Sensor: {sensorData.sensorId}</Text>
        <Text style={styles.dataText}>Temperatura: {sensorData.temperature}°C</Text>
        <Text style={styles.dataText}>Humedad: {sensorData.humidity}%</Text>
        <Text style={styles.locationText}>Ubicación: {sensorData.location}</Text>
      </View>
      
      <TouchableOpacity style={styles.button} onPress={fetchData}>
        <Text style={styles.buttonText}>Actualizar manualmente</Text>
      </TouchableOpacity>
      <Text style={styles.updateText}>
        Última actualización: {new Date(sensorData.lastUpdated).toLocaleTimeString()}
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f5f5f5',
    padding: 20,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  errorContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  errorText: {
    color: 'red',
    fontSize: 18,
    marginBottom: 20,
  },
  retryButton: {
    backgroundColor: '#2196F3',
    padding: 15,
    borderRadius: 5,
  },
  retryButtonText: {
    color: 'white',
    fontSize: 16,
  },
  button: {
    backgroundColor: '#4CAF50',
    padding: 15,
    borderRadius: 5,
    marginBottom: 10,
    marginTop: 20,
  },
  buttonText: {
    color: 'white',
    fontSize: 16,
  },
  updateText: {
    color: '#666',
    marginTop: 10,
  },
  arPanel: {
    backgroundColor: 'rgba(0, 0, 0, 0.7)',
    padding: 20,
    borderRadius: 10,
    width: '100%',
  },
  titleText: {
    fontSize: 20,
    color: '#ffffff',
    textAlign: 'center',
    fontWeight: 'bold',
    marginBottom: 15,
  },
  dataText: {
    fontSize: 18,
    color: '#ffffff',
    textAlign: 'center',
    marginVertical: 8,
  },
  locationText: {
    fontSize: 16,
    color: '#aaaaaa',
    textAlign: 'center',
    marginTop: 8,
  },
});